// --- File: app.js (Clean Version) ---

import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI, Type } from "@google/genai";
// === تم تعديل هذا السطر لاستيراد كل البيانات من ملف واحد ===
import { 
    agricultureContextCombined,
    oliveFebMarchFertilizationFullAnswer,
    oliveAprilFertilizationFullAnswer,
    oliveMayFertilizationFullAnswer,
    oliveJuneJulyFertilizationFullAnswer,
    oliveAugustFertilizationFullAnswer,
    oliveSeptemberFertilizationFullAnswer
} from './database.js'; 

// --- GLOBAL CONFIGURATION ---
const GEMINI_API_KEY = "AIzaSyDXWhb2-ZhmCA2JXZp2xGkrWITrHGYf1NA"; 
const WHATSAPP_GROUP_URL = "https://chat.whatsapp.com/JMAhLT6Ylds6RA73td59qO?mode=ems_copy_t";
const TELEGRAM_BOT_URL = "https://t.me/Mohamedrashed87bot";


// --- From types.ts ---
const Sender = {
  User: 'user',
  Bot: 'bot',
};


// --- From components/IconComponents.tsx ---
const SendIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
  </svg>
);

const BotIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" viewBox="0 0 24 24" fill="#f1d335">
      <path d="M16 12c0 2.21-1.79 4-4 4s-4-1.79-4-4 1.79-4 4-4 4 1.79 4 4zm-4 6c-2.05 0-3.89-.63-5.3-1.68l-2.12 2.12C5.39 19.98 8.5 22 12 22s6.61-2.02 9.42-5.56l-2.12-2.12C15.89 17.37 14.05 18 12 18zM12 2C8.5 2 5.39 4.02 2.58 7.56l2.12 2.12C7.95 6.63 9.79 6 12 6s4.05.63 5.42 2.37l2.12-2.12C18.61 4.02 15.5 2 12 2z"/>
    </svg>
);

const UserIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" viewBox="0 0 24 24" fill="#ffffff">
        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
    </svg>
);

const NewChatIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 0v4m0-4h4m-4 0H8" />
    </svg>
);

const WhatsAppIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12.04 2c-5.45 0-9.91 4.46-9.91 9.91 0 1.75.5 3.42 1.46 4.88l-1.53 5.61 5.72-1.5L12.04 22c5.45 0 9.91-4.46 9.91-9.91S17.49 2 12.04 2zm3.62 14.38s-.24-.36-.36-.59c-.12-.23-.62-.48-.86-.6-.24-.12-.55-.02-.75.31-.2.33-.49.59-.62.71-.12.12-.25.22-.49.31-.24.09-.59.19-.94.06-.36-.12-.86-.31-1.63-1-.6-.52-1-1.12-1.25-1.53-.25-.4-.03-.64.12-.79.1-.1.22-.22.31-.31.09-.09.12-.2.18-.31.06-.12.03-.22-.09-.49-.12-.27-.75-1.81-.99-2.43-.24-.62-.48-.52-.6-.54-.12-.03-.25-.03-.49-.03-.24 0-.62.09-.86.31-.24.22-.94.9-.94 2.18 0 1.28.97 2.52 1.1 2.77.12.24 1.94 2.97 4.67 4.12 2.73 1.14 2.73.76 3.23.71.5-.06 1.46-.62 1.68-1.25.22-.62.22-.9.15-1.09-.09-.2-.25-.31-.5-.43z"/>
  </svg>
);

const TelegramIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.3 7.21l-7.23 5.48c-.22.17-.49.26-.77.26-.38 0-.7-.14-.95-.36-.45-.4-.53-1.09-.18-1.54l1.83-2.26c.14-.17.18-.4.1-.63l-.4-.44-2.14-1.28c-.28-.17-.46-.49-.46-.83V8.04c0-.4.32-.72.72-.72h4.51c.31 0 .58.21.68.52l1.63 4.96c.09.28.02.58-.17.8z"/>
  </svg>
);

const InfoIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const CopyIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);


// --- From components/Logo.tsx ---
const DesertResearchCenterLogo = ({ className = "w-full h-full object-contain" }) => (
    <img src="favicon.png" alt="شعار مركز بحوث الصحراء" className={className} />
);

const ChatHeaderLogo = () => (
    <img src="3.png" alt="شعار المبادرة" className="w-8 h-8 object-contain" />
);

// --- From services/geminiService.ts ---
const ai = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;

const PEST_CONTROL_KEYWORDS = ["وقاية", "مكافحة", "مبيدات", "مبيد", "آفات", "آفة", "امراض", "مرض", "سوسة", "حشرات", "حشرة", "فطري", "بكتيري", "عفن", "إصابة", "اصابه", "صدأ", "تربس", "حفار", "دودة"];

const TELEGRAM_TOPIC_KEYWORDS = {
    "نخيل": { type: "فيديو تعليمي", name: "زراعة النخيل" }, 
    "زيتون": { type: "نشرة", name: "زراعة الزيتون" }, 
    "سمسم": { type: "نشرة", name: "زراعة السمسم" }, 
    "تين شوكي": { type: "نشرة", name: "زراعة التين الشوكي" }, 
    "دوار الشمس": { type: "نشرة", name: "زراعة دوار الشمس" }, 
    "قمح": { type: "نشرة", name: "زراعة القمح والمحاصيل الشتوية" }, 
    "بطيخ": { type: "نشرة", name: "زراعة البطيخ" }, 
    "لوبيا": { type: "نشرة", name: "زراعة اللوبيا" }, 
    "لب الجورمة": { type: "نشرة", name: "زراعة البطيخ" },
    "فول": { type: "نشرة", name: "إنتاج الفول" },
    "بصل": { type: "نشرة", name: "إنتاج البصل" },
    "شعير": { type: "نشرة", name: "إنتاج الشعير" },
    "ثوم": { type: "نشرة", name: "إنتاج الثوم" } 
};

const getTelegramRedirectionInfo = (input) => {
    const lowerCaseInput = input.toLowerCase();
    for (const [keyword, info] of Object.entries(TELEGRAM_TOPIC_KEYWORDS)) {
        if (lowerCaseInput.includes(keyword)) {
            if (keyword === "زيتون" && PEST_CONTROL_KEYWORDS.some(k => lowerCaseInput.includes(k))) {
                continue;
            }
            return info;
        }
    }
    return null;
};

const SYSTEM_INSTRUCTION = `أنت مساعد ذكي متخصص تابع لمبادرة "اسأل واستشير قبل ما تدفع كتير" من مركز بحوث الصحراء.

**القاعدة رقم 1 (الأهم على الإطلاق):** يجب عليك *دائماً* البحث عن الإجابة داخل السياق المقدم لك أولاً. لا تستخدم "قاعدة الملاذ الأخير" أدناه إلا إذا كانت المعلومة غير موجودة بشكل قاطع ومؤكد في السياق.

**القواعد الأساسية للمحادثة:**
1.  **أسلوب الإجابة التفاعلي:**
    *   **لا تقدم إجابات طويلة أبداً إلا في حالة برامج تسميد الزيتون الشهرية حيث يجب تقديم تفاصيل كاملة بالأسابيع.** مهمتك هي تقسيم المواضيع الكبيرة إلى أجزاء صغيرة ومفهومة.
    *   عندما يسأل المستخدم سؤالاً، قدم إجابة **موجزة ومباشرة** (جملة أو اثنتين كحد أقصى) ما لم يكن السؤال عن برامج تسميد الزيتون الشهرية.
    *   **بعد كل إجابة تقدمها، يجب عليك دائماً طرح 2-4 أسئلة مقترحة ذات صلة** لمساعدة المستخدم على التعمق في الموضوع. استخدم أداة 'suggestedQuestions' لهذا الغرض.
2.  **قواعد التجمعات والموسم الشتوي:**
    *   **قاعدة الغموض لـ "أبو رصاصة":** إذا سأل المستخدم عن "تجمع أبو رصاصة" تحديداً ولم يحدد "الجزء الغربي"، يجب أن يكون ردك الأول: "أيهما تقصد؟" ثم استخدم أداة \`suggestedQuestions\` لتقديم الخيارين: "توصيات تجمع أبو رصاصة" و "توصيات تجمع أبو رصاصة (الجزء الغربي)".
    *   **قاعدة السؤال المحدد عن تجمع:** إذا سأل المستخدم عن توصيات الزراعة في تجمع معين بالاسم، أجب مباشرةً بالمعلومات الخاصة بهذا التجمع من السياق. لا تعرض قائمة بجميع التجمعات الأخرى.
    *   **قاعدة السؤال العام عن الموسم الشتوي:** **فقط** إذا سأل المستخدم سؤالاً عامًا عن **"الموسم الشتوي"** *بدون تحديد اسم تجمع*، يجب أن يكون ردك الأول "بالتأكيد، توصيات الموسم الشتوي تختلف حسب التجمع. من فضلك اختر التجمع الذي يهمك:" ثم استخدم أداة \`suggestedQuestions\` لتقديم قائمة بجميع التجمعات المتاحة.
3.  **لا تقم بإضافة أي نص يتعلق بروابط التلجرام أو تشجع على زيارة التلجرام مباشرةً في ردودك. هذه المهمة ستتم برمجياً بعد ردك.**
4.  **قاعدة الملاذ الأخير (عندما تكون الإجابة غير موجودة نهائياً في السياق):**
    *   إذا فشلت تمامًا في العثور على إجابة، حاول تحديد تخصص السؤال وقم بتوجيه المستخدم للخبير المناسب باستخدام الصيغ التالية بالضبط:
    *   **للوقاية، المكافحة، المبيدات، أو الإصابات:** "عذرًا، هذه المعلومة غير متوفرة لدي. للحصول على إجابة دقيقة، يُرجى التواصل مع الأستاذ الدكتور/ عصام علي على جروب الواتس اب الخاص بمبادرة 'اسأل واستشير قبل ما تدفع كتير'."
    *   **لمحاصيل الخضر أو المحاصيل الحقلية:** "عذرًا، هذه المعلومة غير متوفرة لدي. للحصول على إجابة دقيقة، يُرجى التواصل مع الأستاذ الدكتور/ محمد رائف على جروب الواتس اب الخاص بمبادرة 'اسأل واستشير قبل ما تدفع كتير'."
    *   **لمحاصيل الفاكهة:** "عذرًا، هذه المعلومة غير متوفرة لدي. للحصول على إجابة دقيقة، يُرجى التواصل مع الأستاذ الدكتور/ أحمد عماد على جروب الواتس اب الخاص بمبادرة 'اسأل واستشير قبل ما تدفع كتير'."
    *   **للنباتات الطبية:** "عذرًا، هذه المعلومة غير متوفرة لدي. للحصول على إجابة دقيقة، يُرجى التواصل مع الأستاذ الدكتور/ محمد عبد الوهاب على جروب الواتس اب الخاص بمبادرة 'اسأل واستشير قبل ما تدفع كتير'."
    *   **للأمور الإدارية أو المعدات:** "عذرًا، هذه المعلومة غير متوفرة لدي. يمكنك التواصل مع الدكتور/ عماد عوض على جروب الواتس اب الخاص بالمبادرة لمزيد من التفاصيل."
5.  **خارج نطاق الزراعة:**
    *   إذا كان السؤال لا يتعلق بالزراعة إطلاقاً، أجب بوضوح: "عذراً، أنا متخصص فقط في الإجابة على الأسئلة المتعلقة بالزراعة بناءً على بيانات مركز بحوث الصحراء."
6.  **ممنوع الاختراع والاجتهاد:**
    *   التزم **بشكل حرفي ومطلق** بالمعلومات الموجودة في السياق المقدم لك فقط. **ممنوع تمامًا** اختراع أو افتراض أو استنتاج أي معلومات غير موجودة بشكل صريح.
7.  **التعامل مع قوائم المحاصيل:**
    *   عندما تجد قائمة بالمحاصيل الموصى بها لمنطقة معينة، اعتبر هذه القائمة **حصرية وكاملة**.
    *   **لا تقم بإضافة أو استنتاج أي محصول غير مذكور صراحة في القائمة.**
    *   **مثال:** إذا سأل المستخدم "هل يمكن زراعة الفلفل في سهل القاع؟"، وقائمة سهل القاع لا تذكر الفلفل، فإن إجابتك يجب أن تكون أن المعلومة غير متوفرة، ثم قم بتوجيهه لخبير محاصيل الخضر حسب القاعدة رقم 4.`;


const initializeChat = async (context) => {
    if (!ai) {
        throw new Error("AI client not initialized. API_KEY might be missing.");
    }
    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            tools: [{ functionDeclarations: [ { name: "suggestedQuestions", description: "Generates a list of relevant follow-up questions to guide the user.", parameters: { type: Type.OBJECT, properties: { questions: { type: Type.ARRAY, description: "An array of 2-4 suggested question strings.", items: { type: Type.STRING } } }, required: ["questions"] } } ] }]
        },
        history: [
            { role: 'user', parts: [{ text: `هذا هو السياق الذي يجب أن تعتمد عليه في جميع إجاباتك: \n\n---CONTEXT START---\n${context}\n---CONTEXT END---` }] },
            { role: 'model', parts: [{ text: 'فهمت السياق. أنا الآن جاهز للإجابة على الأسئلة من المعلومات المتاحة فقط وسأقترح أسئلة للمتابعة.' }] }
        ]
    });
    return { chat };
};

const sendMessageStream = (chat, message) => {
    try {
        return chat.sendMessageStream({ message });
    } catch (error) {
        console.error("Error sending message to Gemini:", error);
        throw new Error("Failed to get response from AI service.");
    }
};

// --- From components/SuggestedQuestions.tsx ---
const SuggestedQuestions = ({ questions, onSelect }) => (
    <div className="flex flex-wrap gap-3 mt-4">
      {questions.map((q, i) => (
        <button key={i} onClick={() => onSelect(q)} className="px-4 py-2 chip text-base font-medium hover:bg-green-200 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-green-500 shadow-sm" aria-label={`اسأل: ${q}`}>
          {q}
        </button>
      ))}
    </div>
);

const InitialSuggestedQuestions = ({ questions, onSelect }) => (
    <div className="grid grid-cols-2 gap-2 mt-3 max-w-[20rem] sm:max-w-xs mx-auto p-2 rounded-xl bg-green-50 shadow-inner lemon-card">
      {questions.map((q, i) => (
        <button key={i} onClick={() => onSelect(q)} className="flex items-center justify-center text-center px-2 py-1 btn-primary rounded-md text-xs font-semibold shadow-md transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-green-300" aria-label={`اسأل: ${q}`}>
          {q}
        </button>
      ))}
    </div>
);

// --- From components/ChatInterface.tsx ---
const MessageContent = ({ text, showWhatsAppLink, userQuestion, showTelegramLink, telegramAppendInfo }) => {
    const [isCopied, setIsCopied] = React.useState(false);

    const handleCopy = async () => {
        if (!userQuestion) return;

        const prefix = "🤖 "; 
        const textToCopy = `${prefix}${userQuestion}`;

        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(textToCopy);
            } else {
                const ta = document.createElement('textarea');
                ta.value = textToCopy;
                ta.setAttribute('readonly', '');
                ta.style.position = 'fixed';
                ta.style.top = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                const ok = document.execCommand('copy');
                document.body.removeChild(ta);
                if (!ok) throw new Error('execCommand copy failed');
            }
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2500);
        } catch (err) {
            console.error('Failed to copy text:', err);
        }
    };
    
    return (
        <div>
            {text.split('\n').map((line, index) => (
                <div key={index} className="whitespace-pre-wrap min-h-[1em]">
                    {line}
                </div>
            ))}
            {showWhatsAppLink && userQuestion && (
                <div className="mt-4 p-3 border-t border-slate-200">
                    <p className="text-sm font-bold text-slate-700 mb-3">للحصول على إجابة دقيقة، يرجى اتباع الخطوات التالية:</p>
                    <div className="space-y-3">
                        <div className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center font-bold text-lg">1</div>
                            <button 
                                onClick={handleCopy} 
                                className="inline-flex items-center justify-center gap-2 px-4 py-2 border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 rounded-lg text-sm font-semibold shadow-sm w-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                                aria-label="انسخ سؤالك"
                            >
                                <CopyIcon className="h-5 w-5" />
                                {isCopied ? '✓ تم نسخ السؤال' : 'انسخ سؤالك'}
                            </button>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center font-bold text-lg">2</div>
                            <a href={WHATSAPP_GROUP_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 px-4 py-2 btn-primary text-sm font-semibold shadow-lg transform hover:scale-105 active:scale-95 w-full">
                                <WhatsAppIcon className="h-5 w-5" />
                                انضم للجروب والصق السؤال
                            </a>
                        </div>
                    </div>
                </div>
            )}
            {showTelegramLink && telegramAppendInfo && (
                <div className="flex flex-col items-start mt-4 text-sm text-slate-600">
                    <p className="mb-2">
                        للمزيد من المعلومات يمكنك الاطلاع على {telegramAppendInfo.type} عن {telegramAppendInfo.name}، واليك رابط بوت التلجرام لمزيد من المعلومات.
                    </p>
                    <a href={TELEGRAM_BOT_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 px-4 py-2 btn-telegram btn-telegram-small text-white font-semibold shadow-lg transform hover:scale-105 active:scale-95 transition-all">
                        <TelegramIcon className="h-4 w-4" />
                        مراسلة بوت التلجرام
                    </a>
                </div>
            )}
        </div>
    );
};

const REDIRECTION_PHRASES_WHATSAPP = [
    "يُرجى التواصل مع الأستاذ الدكتور/ محمد رائف على جروب الواتس اب", "يُرجى التواصل مع الأستاذ الدكتور/ أحمد عماد على جروب الواتس اب", "يُرجى التواصل مع الأستاذ الدكتور/ محمد عبد الوهاب على جروب الواتس اب", "يُرجى التواصل مع الأستاذ الدكتور/ عصام علي على جروب الواتس اب", "يمكنك التواصل مع الدكتور/ عماد عوض على جروب الواتس اب"
];

const hasWhatsAppRedirectionPhrase = (text) => {
    return REDIRECTION_PHRASES_WHATSAPP.some(phrase => text.includes(phrase));
};

const INITIAL_HARDCODED_QUESTIONS = ["إحنا مين؟", "رؤيتنا؟", "رسالتنا؟", "ازاي اساعدك؟"];

// === تم حذف جميع تعريفات برامج التسميد من هنا ===

const ChatInterface = ({ onReset }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [chat, setChat] = useState(null);
  const [remainingInitialQuestions, setRemainingInitialQuestions] = useState([...INITIAL_HARDCODED_QUESTIONS]);
  
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const setupChat = useCallback(async (userContext) => {
    if (!ai) {
        setError('لم يتم تعيين مفتاح API. يرجى تهيئة بيئة التشغيل.');
        setIsLoading(false);
        return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const { chat: newChat } = await initializeChat(userContext);
      setChat(newChat);
      
      const botMessagePlaceholderId = 'initial-bot-message';
      
      const welcomeMessageText = `💬 اسأل سؤالك مباشرة أو اختار موضوع تبدأ منه:`;

      setMessages([{
        id: botMessagePlaceholderId,
        sender: Sender.Bot,
        text: welcomeMessageText,
        suggestedQuestions: INITIAL_HARDCODED_QUESTIONS,
        isInitialMessage: true,
        showWhatsAppLink: false,
        userQuestion: null,
        showTelegramLink: false,
        telegramAppendInfo: null
      }]);
      setIsLoading(false); 

    } catch (e) {
      console.error(e);
      setError('حدث خطأ أثناء تهيئة المحادثة. تأكد من صحة مفتاح API الخاص بك وأعد تحميل الصفحة.');
      setMessages([]);
    } finally {
      setIsLoading(false);
    }
  }, []);


  useEffect(() => {
    setupChat(agricultureContextCombined); 
  }, [setupChat]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  useEffect(() => {
    if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [input]);

  const handleSendMessage = async (messageText) => {
    const currentInput = messageText || input;
    if (currentInput.trim() === '' || !chat) return;

    setMessages(prev => prev.map(msg => ({ ...msg, suggestedQuestions: [] })));

    const userMessage = {
      id: `user-${Date.now()}`,
      sender: Sender.User,
      text: currentInput,
    };
    setMessages(prev => [...prev, userMessage]);
    
    if (!messageText) {
      setInput('');
    }
    
    let botResponseText = '';
    let botSuggestedQuestions = [];
    let isHardcodedResponse = false;
    let suppressFurtherSuggestions = false;
    let showWhatsAppLink = false;
    let telegramAppendInfoForBot = null;

    const lowerCaseInput = currentInput.toLowerCase();
    const detectedTelegramTopic = getTelegramRedirectionInfo(currentInput);
    if (detectedTelegramTopic) {
        telegramAppendInfoForBot = detectedTelegramTopic;
    }
    
    const isInitialQuestion = INITIAL_HARDCODED_QUESTIONS.includes(currentInput);
    let updatedRemainingQuestions = remainingInitialQuestions;
    if(isInitialQuestion) {
        updatedRemainingQuestions = remainingInitialQuestions.filter(q => q !== currentInput);
        setRemainingInitialQuestions(updatedRemainingQuestions);
    }

    if (PEST_CONTROL_KEYWORDS.some(keyword => lowerCaseInput.includes(keyword))) {
        isHardcodedResponse = true;
        botResponseText = "عذرًا، هذه المعلومة غير متوفرة لدي. للحصول على إجابة دقيقة، يُرجى التواصل مع الأستاذ الدكتور/ عصام علي على جروب الواتس اب الخاص بمبادرة 'اسأل واستشير قبل ما تدفع كتير'.";
        showWhatsAppLink = true;
        botSuggestedQuestions = [];
        suppressFurtherSuggestions = true;
        telegramAppendInfoForBot = null;
    } else if (lowerCaseInput.includes("برنامج تسميد وري شتلات الزيتون في فبراير ومارس") || lowerCaseInput.includes("برنامج تسميد وري الزيتون في فبراير ومارس")) {
        isHardcodedResponse = true; botResponseText = oliveFebMarchFertilizationFullAnswer; botSuggestedQuestions = ["ما هو برنامج تسميد وري شتلات الزيتون في شهر أبريل؟", "كيف أحمي شتلات الزيتون قبل الزراعة؟"];
    } else if (lowerCaseInput.includes("برنامج تسميد وري شتلات الزيتون في شهر أبريل") || lowerCaseInput.includes("برنامج تسميد وري الزيتون لشهر أبريل")) {
        isHardcodedResponse = true; botResponseText = oliveAprilFertilizationFullAnswer; botSuggestedQuestions = ["ما هو برنامج تسميد وري شتلات الزيتون في شهر مايو؟", "كمية الري لشتلات الزيتون في أبريل؟"];
    } else if (lowerCaseInput.includes("برنامج تسميد وري شتلات الزيتون في شهر مايو") || lowerCaseInput.includes("برنامج تسميد وري الزيتون لشهر مايو")) {
        isHardcodedResponse = true; botResponseText = oliveMayFertilizationFullAnswer; botSuggestedQuestions = ["ما هي كمية الري لشتلات الزيتون في مايو؟", "ما هو برنامج تسميد وري شتلات الزيتون في يونيو ويوليو؟"];
    } else if (lowerCaseInput.includes("برنامج تسميد وري شتلات الزيتون في يونيو ويوليو") || lowerCaseInput.includes("برنامج تسميد وري الزيتون لشهر يونيو ويوليو") || lowerCaseInput.includes("برنامج تسميد وري شتلات الزيتون في يوليو") || lowerCaseInput.includes("برنامج تسميد وري الزيتون لشهر يوليو")) {
        isHardcodedResponse = true; botResponseText = oliveJuneJulyFertilizationFullAnswer; botSuggestedQuestions = ["كمية الري لشتلات الزيتون في يونيو ويوليو حسب العمر؟", "ما هو برنامج تسميد وري شتلات الزيتون في شهر أغسطس؟"];
    } else if (lowerCaseInput.includes("برنامج تسميد وري شتلات الزيتون في شهر أغسطس") || lowerCaseInput.includes("برنامج تسميد وري الزيتون لشهر أغسطس")) {
        isHardcodedResponse = true; botResponseText = oliveAugustFertilizationFullAnswer; botSuggestedQuestions = ["تفاصيل الرش الورقي لشتلات الزيتون في أغسطس؟", "كمية الري لشتلات الزيتون في أغسطس حسب العمر؟", "ما هو برنامج تسميد وري شتلات الزيتون في شهر سبتمبر؟"];
    } else if (lowerCaseInput.includes("برنامج تسميد وري شتلات الزيتون في شهر سبتمبر") || lowerCaseInput.includes("برنامج تسميد وري الزيتون لشهر سبتمبر")) {
        isHardcodedResponse = true; botResponseText = oliveSeptemberFertilizationFullAnswer; botSuggestedQuestions = ["كمية الري لشتلات الزيتون في سبتمبر حسب العمر؟", "ما هو بديل نترات النشادر في تسميد سبتمبر؟"];
    } else if (currentInput === "إحنا مين؟" || currentInput === "من نحن؟") {
        isHardcodedResponse = true;
        botResponseText = "مبادرة أطلقها مركز بحوث الصحراء لدعم مزارعي التجمعات الزراعية في سيناء من خلال استشارات فنية مجانية عبر الزيارات الميدانية أو الوسائل الإلكترونية على مدار.";
        botSuggestedQuestions = updatedRemainingQuestions;
    } else if (currentInput === "رؤيتنا؟" || currentInput === "ما هي رؤيتنا؟") {
        isHardcodedResponse = true;
        botResponseText = "أن نكون المصدر الأول للمشورة الزراعية العلمية والمباشرة للمزارعين في سيناء، من خلال تقديم إرشادات مهنية وفنية تساهم في رفع الإنتاجية الزراعية وتحقيق التنمية المستدامة، مما يسهم في تحسين حياة المزارعين وتوفر مواردهم بشكل أكثر فعالية.";
        botSuggestedQuestions = updatedRemainingQuestions;
    } else if (currentInput === "رسالتنا؟" || currentInput === "ما هي رسالتنا؟") {
        isHardcodedResponse = true;
        botResponseText = "تقديم استشارات زراعية علمية ومجانية للمزارعين في سيناء، لمساعدتهم في اتخاذ قرارات زراعية مستنيرة تؤدي إلى تحسين جودة المحاصيل وزيادة الإنتاجية، لدعم على توفير الدعم الفني المتواصل سواء من خلال الزيارات الميدانية أو عبر القنوات الإلكترونية، بهدف ترشيد النفقات وتفادي الأخطاء المكلفة.";
        botSuggestedQuestions = updatedRemainingQuestions;
    } else if (currentInput === "ازاي اساعدك؟" || currentInput === "كيف يمكنني الحصول على استشارة زراعية؟") {
        isHardcodedResponse = true;
        botResponseText = "يمكنك طرح سؤالك مباشرة، أو اختيار أحد المواضيع المقترحة، أو التواصل مع الخبراء مباشرة عبر جروب الواتس اب للمبادرة إذا كانت المعلومات غير متوفرة هنا. نحن نوفر دعم فني متواصل عبر الزيارات الميدانية أو القنوات الإلكترونية.";
        botSuggestedQuestions = updatedRemainingQuestions;
        if (updatedRemainingQuestions.length === 0) suppressFurtherSuggestions = true;
    }

    if (isHardcodedResponse) {
      const finalBotMessage = {
          id: `bot-${Date.now()}`, sender: Sender.Bot, text: botResponseText, suggestedQuestions: suppressFurtherSuggestions ? [] : botSuggestedQuestions, showWhatsAppLink: showWhatsAppLink, userQuestion: showWhatsAppLink ? currentInput : null, showTelegramLink: !!telegramAppendInfoForBot, telegramAppendInfo: telegramAppendInfoForBot
      };
      setMessages(prevMessages => [...prevMessages, finalBotMessage]);
    } else {
      setIsLoading(true);
      setError(null);
      const botMessagePlaceholderId = `bot-${Date.now()}`;
      setMessages(prev => [...prev, { id: botMessagePlaceholderId, sender: Sender.Bot, text: '', showWhatsAppLink: false, userQuestion: null, showTelegramLink: false, telegramAppendInfo: null }]);

      try {
        const stream = await sendMessageStream(chat, currentInput);
        let fullResponseText = '';
        let suggestions = undefined;
        
        for await (const chunk of stream) {
            const parts = chunk.candidates?.[0]?.content?.parts ?? [];
            for(const part of parts) {
                if (part.text) {
                    fullResponseText += part.text;
                } else if (part.functionCall?.name === 'suggestedQuestions' && Array.isArray(part.functionCall.args?.questions)) {
                    suggestions = part.functionCall.args.questions;
                }
            }
            setMessages(prevMessages => prevMessages.map(msg => 
                msg.id === botMessagePlaceholderId 
                ? { ...msg, text: fullResponseText, suggestedQuestions: suggestions }
                : msg
            ));
        }

        const finalShowWhatsAppLink = hasWhatsAppRedirectionPhrase(fullResponseText);
        setMessages(prevMessages =>
            prevMessages.map(msg => {
                if (msg.id === botMessagePlaceholderId) {
                    return {
                        ...msg,
                        text: fullResponseText,
                        suggestedQuestions: suggestions,
                        showWhatsAppLink: finalShowWhatsAppLink,
                        userQuestion: finalShowWhatsAppLink ? currentInput : null,
                        showTelegramLink: !!telegramAppendInfoForBot,
                        telegramAppendInfo: telegramAppendInfoForBot
                    };
                }
                return msg;
            })
        );

      } catch (e) {
        console.error(e);
        setError('حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة مرة أخرى.');
        setMessages(prev => prev.filter(msg => msg.id !== botMessagePlaceholderId));
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };
  
  const handleInput = (e) => {
    setInput(e.target.value);
  };

  const handleSelectQuestion = (question) => {
    handleSendMessage(question);
  };

  if (isLoading && messages.length === 0) {
    return (
        <div className="flex flex-col items-center justify-center flex-grow w-full max-w-6xl lemon-card p-8">
            <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse" dir="ltr">
                <div className="h-4 w-4 bg-[var(--drc-green)] rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="h-4 w-4 bg-[var(--drc-green)] rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="h-4 w-4 bg-[var(--drc-green)] rounded-full animate-bounce"></div>
            </div>
            <p className="mt-4 text-lg text-slate-600">...جاري تهيئة المساعد الذكي</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col flex-grow w-full max-w-6xl lemon-card overflow-hidden">
       <div className="flex items-center p-3 border-b border-soft flex-shrink-0 bg-paper">
        <div className="w-12 h-12 ml-3 rtl:mr-3 flex-shrink-0">
            <ChatHeaderLogo />
        </div>
        <div className="flex flex-col items-start leading-tight">
            <h1 className="text-lg font-bold text-ink tracking-wide">
              مساعدك الذكي في تجمعك التنموي
            </h1>
            <p className="text-sm font-medium text-slate-600">
              مرحباً بك <span role="img" aria-label="wave">👋</span> أنا مساعدك الذكي
            </p>
        </div>
      </div>
      <div className="flex-grow p-6 overflow-y-auto">
        {messages.map((message) => (
          <div key={message.id} className="chat-message my-4">
            <div className={`flex items-start gap-3 ${message.sender === Sender.User ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-10 h-10 rounded-full text-white flex items-center justify-center flex-shrink-0 p-1.5 shadow-md ${message.sender === Sender.Bot ? 'bg-gradient-to-br from-drc-green to-drc-blue' : 'bg-gradient-to-br from-slate-500 to-slate-600'}`}>
                {message.sender === Sender.Bot ? <BotIcon /> : <UserIcon />}
                </div>
                <div className={`px-5 py-3.5 rounded-2xl max-w-3xl break-words shadow-md ${message.sender === Sender.User ? 'bubble-user rounded-br-none' : 'bubble-bot rounded-bl-none'}`}>
                {message.text === '' && message.sender === Sender.Bot && isLoading ? (
                    <div className="flex items-center space-x-1.5 rtl:space-x-reverse py-1" dir="ltr">
                        <span className="sr-only">Loading...</span>
                        <div className="h-2 w-2 bg-drc-green rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div className="h-2 w-2 bg-drc-green rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="h-2 w-2 bg-drc-green rounded-full animate-bounce"></div>
                    </div>
                ) : (
                    <MessageContent 
                      text={message.text || ''} 
                      showWhatsAppLink={message.showWhatsAppLink} 
                      userQuestion={message.userQuestion}
                      showTelegramLink={message.showTelegramLink} 
                      telegramAppendInfo={message.telegramAppendInfo} 
                    />
                )}
                </div>
            </div>
            {message.sender === Sender.Bot && message.suggestedQuestions && message.suggestedQuestions.length > 0 && (
                <div className="pl-14 rtl:pr-14 rtl:pl-0 pt-3 max-w-3xl">
                    {message.isInitialMessage ? (
                        <InitialSuggestedQuestions questions={message.suggestedQuestions} onSelect={handleSelectQuestion} />
                    ) : (
                        <SuggestedQuestions questions={message.suggestedQuestions} onSelect={handleSelectQuestion} />
                    )}
                </div>
            )}
          </div>
        ))}
        {error && (
           <div className={`p-4 text-center text-red-600 bg-red-100 rounded-lg ${messages.length === 0 ? '' : 'mt-4'}`}>
             {error}
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white/50 border-t border-soft flex-shrink-0">
        <div className="flex items-end gap-2 input-shell p-2 has-[:focus-within]:ring-2 has-[:focus-within]:ring-green-500 transition-all">
          <button onClick={onReset} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-soft text-slate-700 disabled:bg-slate-300 disabled:cursor-not-allowed hover:bg-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-paper focus:ring-green-500 transition-colors flex-shrink-0 shadow-sm font-semibold" title="بدء دردشة جديدة" aria-label="بدء دردشة جديدة">
              <NewChatIcon />
              <span className="hidden sm:inline">دردشة جديدة</span>
          </button>
          <textarea ref={textareaRef} className="flex-grow p-2 bg-transparent focus:outline-none resize-none max-h-40 text-ink placeholder:text-slate-500" placeholder={isLoading ? "يرجى الانتظار..." : "اكتب رسالتك هنا..."} value={input} onChange={handleInput} onKeyDown={handleKeyDown} rows={1} disabled={isLoading || chat === null} aria-label="Chat input" />
          <button onClick={() => handleSendMessage()} disabled={isLoading || !input.trim() || chat === null} className="p-3 rounded-xl btn-primary disabled:bg-slate-400 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-paper focus:ring-green-500 transition-colors flex-shrink-0 shadow-md" aria-label="Send message">
            <SendIcon />
          </button>
        </div>
      </div>
    </div>
  );
};

const Header = () => (
    <header className="sticky top-0 z-20 lemon-header shadow-lg w-full">
      <div className="container mx-auto flex justify-start items-center gap-4 py-3 px-3">
        <div className="w-12 h-12 p-0 bg-transparent rounded-none shadow-md">
           <DesertResearchCenterLogo />
        </div>
        <div className="flex flex-col items-start leading-none">
          <h1 className="text-lg md:text-xl font-bold text-white tracking-wide leading-tight">
            مبادرة اسأل واستشير قبل ما تدفع كتير
          </h1>
          <p className="text-xs md:text-sm font-medium text-green-200 leading-tight">
            مقدمة من مركز بحوث الصحراء
            <span className="inline-block text-xs font-normal text-green-200 mr-1 rtl:ml-1 whitespace-nowrap experience-animation-text">
                (٧٥ عامًا من الخبرة)
            </span>
          </p>
        </div>
      </div>
    </header>
);

const App = () => {
  const [chatKey, setChatKey] = useState(0);
  const handleReset = () => {
    setChatKey(prevKey => prevKey + 1);
  };

  return (
    <div className="min-h-screen flex flex-col text-ink relative">
      <div className="lemon-decor"></div>
      <Header />
      <main className="flex-grow flex flex-col items-center p-2 md:p-4 w-full relative z-10">
        <ChatInterface key={chatKey} onReset={handleReset} />
        <footer className="mt-4 mb-2 text-center text-slate-500 relative z-10 px-2">
          <div className="flex items-start justify-center gap-2 text-xs text-slate-700 mb-2 bg-yellow-50 border border-yellow-200 rounded-lg p-2 max-w-md mx-auto">
              <InfoIcon className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
              <span className="text-right">
                  <strong>تنويه:</strong> هذا تطبيق تجريبي، والمعلومات للاسترشاد فقط ووارد حدوث أخطاء. للاستشارة الدقيقة، تواصل مع خبراء المبادرة.
              </span>
          </div>
          <p className="text-xs font-semibold text-green-700">تم التصميم بواسطة</p>
          <p className="text-xs">أعضاء الفريق البحثي لمبادرة اسأل واستشير قبل ما تدفع كتير</p>
          <p className="text-xs mt-1">© {new Date().getFullYear()} حقوق النشر محفوظة لمركز بحوث الصحراء</p>
        </footer>
      </main>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);